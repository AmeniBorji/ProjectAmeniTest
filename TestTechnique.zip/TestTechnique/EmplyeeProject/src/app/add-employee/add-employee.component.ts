import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  constructor(private service:EmployeeService,
    private route:Router,
 ) { }

  ngOnInit(): void {
    
  }
  add(employee){
    console.log(employee);
    this.service.addData(employee);
    
   
    this.route.navigateByUrl("list")
    

  }
  back(){
    this.route.navigateByUrl("list")

  }
}
