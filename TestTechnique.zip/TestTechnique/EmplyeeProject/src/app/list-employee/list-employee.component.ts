import { Component, OnInit, ViewChild } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';
import * as $ from "jquery";
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-employee',
  templateUrl: './list-employee.component.html',
  styleUrls: ['./list-employee.component.css']
})
export class ListEmployeeComponent implements OnInit {
  
  @ViewChild('dataTable') table;
  dataTable:any;
list:Employee[]=[];
p: number = 1;
  constructor(public service:EmployeeService,private route:Router,
    ) { }
search:string;

  ngOnInit(): void {
  
    this.service.getData().subscribe(data=>{

      this.service.list=data['data'];
     
      
     

    })

  }
  addData(item){
    item.id=this.list[this.list.length-1].id+1
    this.service.list.push(item);
   

  }
  removeData(item){
    let conf=confirm("Are yous sure that you want to delete it  ?")
    if(conf){
  this.service.deleteEmployee(item);}}
 
  gotoAdd(){
this.route.navigateByUrl("add")
  }
  recherche(){
    if (this.search==""){
      this.ngOnInit();
    }else{
      this.service.list=this.service.list.filter(res=>{
        return res.employee_name.toLocaleLowerCase().match(this.search.toLowerCase())
      })
    }
  }
  key:string='name'
  reverse:boolean=false;
  sort(key){
    this.key=key
    this.reverse=!this.reverse
  }
  
}
