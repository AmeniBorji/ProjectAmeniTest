import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  list:Employee[]=[];
url:string="https://dummy.restapiexample.com/api/v1/employees"
  constructor(private http:HttpClient) { }
  getData(): Observable<any> {
     
    return this.http.get(`${this.url}`);

  }
  addData(item){
    item.id=this.list[this.list.length-1].id+1
    this.list.push(item);
    console.log(this.list)
    
    

  }
  deleteEmployee(employee){
    let i =this.list.indexOf(employee);
    this.list.splice(i,1);
   }
}
