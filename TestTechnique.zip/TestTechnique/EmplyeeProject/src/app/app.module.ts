import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule} from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListEmployeeComponent } from './list-employee/list-employee.component';
import {NgxPaginationModule} from 'ngx-pagination';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { FormsModule} from '@angular/forms';
import { Ng2OrderModule} from 'ng2-order-pipe';
import { Ng2SearchPipeModule} from 'ng2-search-filter';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatInputModule} from '@angular/material/input';






@NgModule({
  declarations: [
    AppComponent,
    ListEmployeeComponent,
    AddEmployeeComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    NgxPaginationModule,
    FormsModule,
    Ng2SearchPipeModule,
    Ng2OrderModule,
    BrowserAnimationsModule,
    MatInputModule,
  
   
  
 
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
